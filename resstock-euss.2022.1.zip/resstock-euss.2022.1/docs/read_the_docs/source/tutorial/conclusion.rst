Conclusion
==========

Congratulations, you have now completed your first ResStock analysis. See the other sections in this documentation for more advanced topics. 

