Cambium data obtained from https://data.nrel.gov/system/files/183/Cambium21_LRMER_GEAregions.xlsx

User Inputs		
Emission: CO2e
Emission stage: Combined
Start year: 2023
Evaluation period (years): 20
Discount rate (real): 0.03
Global Warming Potentials: 100-year (AR5)
Location: End-use
